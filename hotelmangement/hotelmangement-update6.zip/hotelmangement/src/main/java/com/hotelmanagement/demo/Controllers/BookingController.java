package com.hotelmanagement.demo.Controllers;

import com.hotelmanagement.demo.Models.Booking;
import com.hotelmanagement.demo.Models.Room;
import com.hotelmanagement.demo.Repositories.BookingRepository;
import com.hotelmanagement.demo.Repositories.GuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Controller
public class BookingController {
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private GuestRepository  g;

    @PostMapping("/booking")
    Booking newBooking(@RequestBody Booking newBooking){
        return bookingRepository.save(newBooking);
    }


    @GetMapping("/booking")
    public String showBooked(Model model) {
        model.addAttribute("bookings", g.getBookedGuest());
        return "booking";
    }
}
