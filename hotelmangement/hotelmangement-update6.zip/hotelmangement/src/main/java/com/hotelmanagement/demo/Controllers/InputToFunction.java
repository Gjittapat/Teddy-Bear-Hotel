package com.hotelmanagement.demo.Controllers;

public class InputToFunction {
    private int id;

    // status: check in or check out
    private String status;

    public void setId(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }

    // constructor
    public void InputToFunction(int id){
        this.id = id;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }




}
