package com.hotelmanagement.demo.Controllers;

import com.hotelmanagement.demo.Models.Booking;
import com.hotelmanagement.demo.Models.Payment;
import com.hotelmanagement.demo.Repositories.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class PaymentController {
    @Autowired
    private PaymentRepository paymentRepository;
    @PostMapping("/payment")
    Payment newPayment(@RequestBody Payment newPayment){
        return paymentRepository.save(newPayment);
    }

    @GetMapping(value = "/payment")
    List<Payment> getBooking(){
        return paymentRepository.findAll();
    }

}
