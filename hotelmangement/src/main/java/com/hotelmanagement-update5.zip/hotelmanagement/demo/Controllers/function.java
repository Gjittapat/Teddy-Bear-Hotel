package com.hotelmanagement.demo.Controllers;
import com.hotelmanagement.demo.Models.Guest;
import com.hotelmanagement.demo.Repositories.GuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
public class function {
    @Autowired
    private GuestRepository guestFunction;


    // check out(update method)
    @PutMapping("/function/check_out/{id}")
    public String check_out(@PathVariable int id) {
        String status = guestFunction.getStatus(id);
        if (status.equalsIgnoreCase("check in")) {
            guestFunction.checkOutById(id);
            return null;
        } else {
            return "this guest has already checked out!";
        }
    }

    // check in(update method)
    @PutMapping("/function/check_in/{id}")
    public String check_in(@PathVariable int id) {
        String status = guestFunction.getStatus(id);
        if (status.equalsIgnoreCase("booking")) {
            guestFunction.checkInById(id);
            return null;
        } else {
            return "cannot check in!";
        }
    }

    // cancel booking(delete method)
    @DeleteMapping("/guest/cancel_booking/{id}")
    public String cancelBooking(@PathVariable int id) {
        String status = guestFunction.getStatus(id);
        if (status.equalsIgnoreCase("booking")) {
            guestFunction.deleteBookingById(id);
            guestFunction.deleteGuestById(id);
            return null;
        } else {
            return "cannot cancel booking";
        }
    }

    @GetMapping("/check-in")
    public String showCheckIn(Model model) {
        model.addAttribute("inputToFunction", new InputToFunction());

        return "check-in";
    }

    @PostMapping("/check-in")
    public String checkInF(@ModelAttribute InputToFunction inputToFunction, Model model) {
        model.addAttribute("inputToFunction", inputToFunction);
        System.out.println(inputToFunction.getId());
        
        String status = guestFunction.getStatus(inputToFunction.getId());
        if(inputToFunction.getStatus().equalsIgnoreCase("CHECKIN")){
            if (status.equalsIgnoreCase("booking")) {
                guestFunction.checkInById(inputToFunction.getId());
            }
        }
        if(inputToFunction.getStatus().equalsIgnoreCase("CHECKOUT")){
            if (status.equalsIgnoreCase("check in")) {
                guestFunction.checkOutById(inputToFunction.getId());
            }
        }
        return "check-in";
    }
}



