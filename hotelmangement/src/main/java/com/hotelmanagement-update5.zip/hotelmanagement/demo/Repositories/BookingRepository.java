package com.hotelmanagement.demo.Repositories;

import com.hotelmanagement.demo.Models.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Integer > {
    @Query(value = "select * from booking as b inner join payment as p on booking.booking_id = p.booking_id", nativeQuery = true)
    List<Booking> showBookingjoinPayment();
}
