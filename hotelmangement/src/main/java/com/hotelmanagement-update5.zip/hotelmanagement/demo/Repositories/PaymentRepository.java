package com.hotelmanagement.demo.Repositories;

import com.hotelmanagement.demo.Models.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {
}
